<head>
    <title>Robotics Code Raul</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ asset('/assets/img/favpng.png') }}" rel="icon">
    <link rel="stylesheet" type="text/css" href="{{ asset('/assets/css/register.css') }}">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i"
        rel="stylesheet">


    <link rel="stylesheet" href="{{ asset('/assets/libs/mdi-font/css/material-design-iconic-font.min.css') }}"
        media="all">
    <link rel="stylesheet" href="{{ asset('/assets/libs/font-awesome-4.7/css/font-awesome.min.css') }}" media="all">

    <link rel="stylesheet" href="{{ asset('/assets/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/assets/libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/assets/libs/datepicker/daterangepicker.css') }}" rel="stylesheet"
        media="all">
    <link rel="stylesheet" href="{{ asset('/assets/libs/select2/dist/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/assets/css/register.css') }}">
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-y: auto;
        }
    </style>
</head>
